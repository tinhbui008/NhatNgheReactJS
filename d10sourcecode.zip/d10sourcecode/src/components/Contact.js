// src/components/Contact.js
import { ContactForm } from './ContactForm';
export const Contact = () => {
    return (
        <div>
            <h2>CONTACT PAGE</h2>

            <ContactForm />
        </div>
    )
}