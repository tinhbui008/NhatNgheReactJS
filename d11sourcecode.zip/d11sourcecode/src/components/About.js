// src/components/About.js
export const About = () => {
    return (
        <div>
            <h2>About</h2>
        </div>
    )
}